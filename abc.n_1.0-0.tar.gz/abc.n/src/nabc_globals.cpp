#include "nabc_globals.h"


char nabcGlobals::BUFFER[256]= "";

